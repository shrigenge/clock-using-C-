#include<iostream>
#include<time.h>   //for sleep function
#include<unistd.h>
#include<stdlib.h>

using namespace std;
int main()
{
    int hour, minute, second;
    cout<<"Enter current time:"<<endl;
    cin>>hour>>minute>>second;
    while(1)
    {
        system("clear");
        cout<<hour<<":"<<minute<<":"<<second<<endl;
        fflush(stdout);
        
        second++;
        
        if(second == 60)
        {
            minute = minute + 1;
            second = 0;
        }
        if(minute == 60)
        {
            hour = hour + 1;
            minute = 0;
        }
        if(hour == 24)
        {
            hour = hour + 1;
            hour = 0;
            minute = 0;
            second = 0;
        }
         sleep(1);
    } //while ends
   
    return 0;
    
}// main ends
